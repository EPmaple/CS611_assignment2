/*
 * Main.java
 * Entry point of the program.
 */

public class Main {
  public static void main(String[] args) {
    GameConsole gameConsole = new GameConsole();
    gameConsole.startGame();
  }
}